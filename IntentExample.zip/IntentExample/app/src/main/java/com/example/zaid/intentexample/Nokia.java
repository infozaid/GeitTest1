package com.example.zaid.intentexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Nokia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nokia);

        Bundle appleData=getIntent().getExtras();
        if(appleData==null)
        {
            return;
        }
        String appleMessage= appleData.getString("appleMessage");
        final TextView nokiaText=(TextView)findViewById(R.id.nokiaText);
        nokiaText.setText(appleMessage);
    }
}
